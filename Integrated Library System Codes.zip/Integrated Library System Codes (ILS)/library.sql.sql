CREATE DATABASE `library`;

USE `library`;

CREATE TABLE `user`
(
  `userID` VARCHAR(20) NOT NULL,
  password VARCHAR(50) NOT NULL,
  PRIMARY KEY (`userID`)
);

INSERT INTO `user` (`userID`, `password`) VALUES
("admin1", "password"),
("admin2", "password"),
("admin3", "password");

CREATE TABLE `book`
(
  `bookID` INT NOT NULL,
  `bookTitle` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`bookID`)
);

INSERT INTO `book` (`bookID`, `bookTitle`) VALUES
(1, "Unlocking Android"),
(2, "Android in Action, Second Edition"),
(3, "Specification by Example"),
(4, "Flex 3 in Action"),
(5, "Flex 4 in Action"),
(6, "Collective Intelligence in Action"),
(7, "Zend Framework in Action"),
(8, "Flex on Java"),
(9, "Griffon in Action"),
(10, "OSGi in Depth");

CREATE TABLE `adminUser`
(
  `userID` VARCHAR(20) NOT NULL,
  password VARCHAR(50) NOT NULL,
  PRIMARY KEY (`userID`)
);

INSERT INTO `adminUser` (`userID`, `password`) VALUES
("admin1", "password"),
("admin2", "password"),
("admin3", "password");

CREATE TABLE `reservation`
(
  `reserveDate` DATE NOT NULL,
  `userID` VARCHAR(20) NOT NULL,
  `bookID` INT NOT NULL,
  PRIMARY KEY (`userID`, `bookID`),
  FOREIGN KEY (`userID`) REFERENCES User(`userID`),
  FOREIGN KEY (`bookID`) REFERENCES `book` (`bookID`)
);

CREATE TABLE `borrowing`
(
  `borrowDate` DATE NOT NULL,
  `dueDate` DATE NOT NULL,
  `userID` VARCHAR(20) NOT NULL,
  `bookID` INT NOT NULL,
  PRIMARY KEY (`userID`, `bookID`),
  FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  FOREIGN KEY (`bookID`) REFERENCES `book` (`bookID`)
);

CREATE TABLE `payment`
(
  `paymentAmount` FLOAT NOT NULL,
  `paymentDate` DATE NOT NULL,
  `paymentNo` INT NOT NULL,
  `userID` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`paymentNo`),
  FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
);

CREATE TABLE `fine`
(
  `fineAmount` FLOAT NOT NULL,
  `userID` VARCHAR(20) NOT NULL,
  `paymentNo` INT ,
  PRIMARY KEY (`userID`),
  FOREIGN KEY (`userID`) REFERENCES User(`userID`),
  FOREIGN KEY (`paymentNo`) REFERENCES `payment` (`paymentNo`)
);